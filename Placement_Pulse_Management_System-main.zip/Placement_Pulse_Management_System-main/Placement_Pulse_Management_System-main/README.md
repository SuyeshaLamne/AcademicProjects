# Placement_portal_management

This project contains mainly three modules namely student, staff, admin.
