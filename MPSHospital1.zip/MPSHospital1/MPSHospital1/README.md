# INFO-5100-AED-Final-Project

# MPSS Hospital


## Project Description
- The healthcare sector is grappling with a significant issue in establishing a unified platform for managing vaccinations, organ transplants, and blood donations. The absence of effective online tools poses challenges for healthcare entities, including emergency services, supply chains, and donation banks, hindering seamless coordination and collaboration. Consequently, individuals requiring vaccines, organ transplants, or blood encounter various obstacles in the system.

- In response to this challenge, we've created a comprehensive application that offers a unified platform for all healthcare-related enterprises. Our application simplifies the logistics and procedures for patients in need of vaccines, organ transplants, or blood, enhancing the efficiency of connecting and coordinating among healthcare professionals, ambulance services, donors, pharmacists, suppliers, and emergency units.

- Our platform establishes connections among crucial participants in the healthcare system, linking Healthcare, DonorBank, Pharmacy, Lab, EmergencyUnit, SupplyChain, and Vaccination enterprises. The application encompasses various organizations, including Administrators, Doctors, Patients, Nurses, Labs, Pharmacists, Suppliers, EmergencyUnits, DonorBanks, and Vaccination Centers, collaborating collectively to enhance the overall quality of healthcare.

- Through our platform, patients can now navigate the intricacies of requesting vaccines, organ transplants, or blood without unnecessary concerns. We've designed a user-friendly platform that streamlines the patient experience, guaranteeing timely and efficient access to the necessary care. Our objective is to establish an improved healthcare system that is attentive to patient needs and actively contributes to their well-being.


